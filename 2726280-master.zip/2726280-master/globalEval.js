// Evaluates a script in a global context
// Workarounds based on findings by Jim Driscoll
// http://weblogs.java.net/blog/driscoll/archive/2009/09/08/eval-javascript-global-context
// pulled from jquery.core source

var globalEval =  function( data ){
	if ( data ) {
		// We use execScript on Internet Explorer
		// We use an anonymous function so that context is window
		// rather than jQuery in Firefox
		( window.execScript || function( data ) {
			window[ "eval" ].call( window, data );
		})( data );
	}
};